# Acil Klinik Asistanı

Tek dosyalık çevrimdışı klinik karar destek prototipi.

## GitHub Pages kurulumu
1. GitHub'da yeni bir public repository oluşturun.
2. Bu klasördeki `index.html` dosyasını repository kök dizinine yükleyin.
3. Repository içinde Settings → Pages bölümüne girin.
4. Source: Deploy from a branch
5. Branch: main, folder: /(root)
6. Save düğmesine basın.

Yayın adresi genellikle:
`https://KULLANICI-ADINIZ.github.io/REPOSITORY-ADI/`

> Klinik kararın yerine geçmez.
